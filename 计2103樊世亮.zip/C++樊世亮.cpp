#include<iostream>
using namespace std;
//冒泡排序
void sort(int *arr,int l);//函数声明

int main()
{
//定义数组
    int arr[]= {2,1,3,12,6,4,9,47,10};
    int l=sizeof(arr)/sizeof(arr[0]);//l为数字的数量
    sort(arr,l);


    return 0;
}


void sort(int *arr,int l)//函数
{
     for(int i=1; i<l; i++)//2.然后再找到第二大的数等等
    {
        for( int j=1; j<l; j++)//1.先找到最大的数
        {
            if(arr[j]<arr[j-1])//前面的小于后面的交换数字
            
            { 
                int t=0;
                t=arr[j];
                arr[j]=arr[j-1];
                arr[j-1]=t;
            }
            else
            {
            continue;
            }
        }
    }
    for(int n=0; n<l; n++)//打印数据
    {
        cout <<arr[n] << " ";
    }

}


    